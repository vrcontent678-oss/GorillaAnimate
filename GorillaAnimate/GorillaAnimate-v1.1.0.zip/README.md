# Gorilla Animate

A clean-room **Gorilla Tag mocap recorder** and **Blender retarget add-on**.

It is built to look and feel like an in-game mod menu, but every button is about one thing: recording your local Gorilla's joint transforms and baking them onto a Gorilla rig in Blender.

* No Harmony patches, no gameplay changes, no network traffic.
* Records your **local player only**.
* Writes **one file per clip**: a `.gamc` (Gorilla Animate Motion Capture) binary, organised into room and date folders.
* The Blender add-on reads `.gamc` and retargets it onto your **`Gorilla_IK_Rig`** (or any selected armature) from a button in the **N sidebar**, so it works with any Gorilla model you already have.

---

## Files

| Path | What it is |
| --- | --- |
| `GorillaAnimate.dll` | The built BepInEx 5 plugin. |
| `package/BepInEx/plugins/GorillaAnimate/GorillaAnimate.dll` | The same DLL in the standard plugin folder layout. |
| `GorillaAnimate-v1.1.0.zip` | Ready-to-extract bundle (BepInEx + Blender + README). |
| `Blender/gorilla_animate_gamc.py` | Blender add-on: `.gamc` retarget importer. |
| `Blender/example_recording.gamc` | Small example clip for testing the add-on. |
| `src/GorillaAnimate/` | Full C# source and `.csproj`. |

---

## Install

1. You already have **BepInEx 5.x** in the Gorilla Tag folder.
2. Copy the `GorillaAnimate` folder from `package/BepInEx/plugins/` into:

   ```
   <Gorilla Tag>\BepInEx\plugins\GorillaAnimate\
   ```

   The result should be:

   ```
   <Gorilla Tag>\BepInEx\plugins\GorillaAnimate\GorillaAnimate.dll
   ```

3. Launch the game and join a room. Press the left controller **Y** button to open the menu in your left hand.
   (It starts open by default.)

### MonkeModManager

MonkeModManager installs from its curated `MonkeModInfo` list, so a brand-new local mod cannot show up in that list by itself. This package uses the same `BepInEx/plugins/<Mod>/<Mod>.dll` layout MMM installs to, so you can extract the zip into the Gorilla Tag folder or add it to a custom MMM list. The DLL is also sitting at the root of this folder, as requested.

---

## In-game menu

* Held just above your **left hand**, like a hand-held tablet, and turned to face your head.
* **Press the left controller Y button** to open it and press Y again to close it.
  It starts open by default; set `ShowMenu=false` to start closed.
* Poke a button with your **right index fingertip**; a small haptic click confirms it.
* **RECORD** → starts sampling. The label changes to **STOP + SAVE**; stopping saves automatically.
* **SAVE** → writes the current buffer without stopping (useful for a checkpoint).
* **FPS** → cycles 24 / 30 / 60 / 90.

Keyboard fallback (desktop window and shortcuts):

| Key | Action |
| --- | --- |
| `F8` | Start / stop recording |
| `F9` | Save now |
| `F10` | Cycle FPS |
| `F7` | Toggle the in-world menu (keyboard fallback for Y) |
| `F6` | Toggle the desktop status window |

Settings live in:

```
<Gorilla Tag>\BepInEx\config\com.rayan.gorillaanimate.cfg
```

`FPS`, `MaxMinutes`, `ShowMenu`, `Scale`, `DesktopGui`. `ShowMenu` controls whether the in-world menu starts open (Y always toggles it); `Scale` changes the menu size.

---

## Recordings

Every save writes exactly one `.gamc` file, sorted by room and then by date:

```
<Gorilla Tag>\BepInEx\plugins\GorillaAnimate\Recordings\
    <ROOM>\
        2026-11-10\
            mocap_20261110_143012_517.gamc
            mocap_20261110_143145_004.gamc
```

* `<ROOM>` is the current Photon room name, cleaned up for Windows. Players outside a room get `NoRoom`.
* The date folder uses your local date.
* The file name is `mocap_<yyyyMMdd_HHmmss_fff>.gamc`, so clips taken in one session sort chronologically.

### What is recorded

One sample per frame at the configured `FPS`, holding 10 floats per joint in **Unity world space**:

```
[px, py, pz, qx, qy, qz, qw, sx, sy, sz]
```

The recorder samples **every bone of the visible gorilla skeleton** (`VRRig.mainSkin.bones`), so the torso, arms, hands and any legs the model has are all captured as they are actually posed in game. The game's own bone names are kept.

Sampling happens **once per rendered frame, at end of frame**, after the game has finished posing the rig. Reading the transforms during `Update` can catch the rig half way through its own update — the head already on this frame's pose while the hands are still on the last one — which looks exactly like hands and fingers spinning faster than they really moved.

The configured `FPS` is a target, not a guarantee: the game only renders as fast as it can. The header keeps the target, but every sample also stores its real timestamp, so playback runs at true speed. The end of the log line after a save reports what was actually captured, for example:

```
Gorilla Animate: 592 samples over 16.40 s = 36.0 Hz (target 60, 28 joints)
```

The joints the game exposes directly are renamed to stable semantic names, so they still map if a future update renames the model:

| Joint | Meaning |
| --- | --- |
| `root` | Gorilla rig root (drives root motion) |
| `body` | Body / hips transform |
| `head` | Head |
| `hand.L`, `hand.R` | Hands |
| `thumb.01/02.L/R`, `index.01/02/03.L/R`, `middle.01/02/03.L/R` | Fingers |

Gorilla Tag does not track a spine: the body transform is smoothly lerped toward the head's rotation, which is why the torso and head can look nearly identical when you stand still. Everything the game actually exposes is recorded; nothing is synthesised.

Recording stops automatically at **10 minutes** by default to protect memory. Change `MaxMinutes` in the config.

### `.gamc` format

All values are little-endian.

| Type | Field |
| --- | --- |
| `char[4]` | `"GAMC"` |
| `uint16` | format version (`1`) |
| `uint16` | FPS |
| `uint32` | frame count |
| `uint16` | joint count |
| `uint16` | flags (`1` = whole skinned skeleton, `0` = legacy 1.0.0 head+hands file) |
| string | creation time, UTC ISO-8601 |
| string | room name |
| joint table | `joint count` × (`string` name, `int16` parent index, `-1` = root) |
| times | `frame count` × `float32` seconds since recording start |
| frames | `frame count` × `joint count` × `float32[10]` |

A `string` is a `uint16` byte length followed by that many UTF-8 bytes. Each frame is stored joint by joint, 10 floats per joint, in the order of the joint table.

---

## Blender add-on

Tested with **Blender 4.5** (works on 3.6+).

### Install

1. `Edit > Preferences > Add-ons > Install...`
2. Pick `Blender/gorilla_animate_gamc.py`.
3. Enable **Gorilla Animate (.gamc)**.

### Use

1. Select your gorilla armature (`Gorilla_IK_Rig`), in Object Mode.
2. Open the 3D Viewport sidebar with **N** and click the **Gorilla Animate** tab.
3. Press **Import .gamc File** and pick a recording. `Blender/example_recording.gamc` is a good first test.

The panel shows which rig will receive the animation, its bone count and current action, plus a summary of the last import.

`File > Import > Gorilla Animate Mocap (.gamc)` does the same thing.

The add-on bakes a new Action onto the rig; nothing is replaced or overwritten.

The target rig is resolved in this order:

1. the selected armature, if it is named `Gorilla_IK_Rig`;
2. any other selected armature;
3. any armature in the scene named `Gorilla_IK_Rig`.

That means selecting the body mesh instead of the armature still works.

### Options

* **Target**
  * `Selected armature` (default) — retarget onto `Gorilla_IK_Rig` (or whichever armature is selected).
  * `New preview armature` — build a fresh armature straight from the recording. Handy for checking a clip, or for using the result as a retarget source.
* **Pose**
  * `Recorded positions` (default) — each recorded joint is put on its **recorded world position** (scaled to the rig), and each bone follows the recorded **rotation change** from the first frame, swung onto the next recorded joint. MonkeMocap records absolute tracker transforms; the positions are absolute here too, but a tracker's absolute rotation is not a Blender bone rotation, so the rotation is applied relative to the rig's bind pose. The clip's frame-0 facing is rotated onto the rig's rest facing first, so a recording that starts facing any direction still comes out facing forward. This removes the drift of driving an A-pose rig from a recording that changes pose, while keeping limbs connected.
  * `Rotation deltas` — the older behaviour: apply the recorded rotation change on top of the rig's rest pose, without placing joints at their recorded positions. Useful when the rig's rest pose is already the pose the recording starts in.
* **Root motion** — keep the player's recorded world movement. Turn it off to keep the character in place while the joints still animate.
* **Motion scale** — scale for the recording. `0` (default) automatically matches the recorded joint spacing to the selected rig's joint spacing, so clips fit both small and large Gorilla models. Set a number to override it.
* **Frame step** — import every Nth sample (`1` = all). Useful for long clips.
* **Set scene FPS** — set the scene frame rate to the recording's frame rate so playback runs at real speed. Turn it off to keep the scene's current rate.
* **Mute constraints** — mute **every** bone constraint on the rig (IK, Copy Rotation, Child Of, ...) because an IK rig ignores baked FK channels, and a live constraint on a control bone (often an unmapped one) moves the parent a hand is attached to, which drags the hand off the arm. Muting is reversible in the bone's constraint panel. Turn it off to leave the rig untouched.
* **Connect chains** — used by `Rotation deltas`: keep hands, feet and the head on the ends of the arms, legs and neck. IK rigs often parent a hand to a control bone instead of the forearm, which leaves the hand floating next to the arm; with this on (default) the import positions such bones on their chain parent's end and keys their `location` to do it. `Recorded positions` already places every joint itself, so it does not need this.
* **Smoothing** — average this many neighbouring samples (`1` by default, `0` disables). A game frame rate dip means one sample can hold two frames of controller rotation; averaging removes that jitter from fast hand and finger motion without the lag of a plain low-pass filter. Set it higher for noisy clips, `0` for the raw recording.

### How the retarget works

* Joint names are tokenised (`LeftForeArm` → `left`, `fore`, `arm`) and matched by body part, side and segment, so `hand.L`, `LeftHand` and `l_hand` all land on the same target bone. Legs (`LeftUpLeg`, `LeftLeg`, `LeftFoot`) are matched too.
* In the default **Recorded positions** mode every matched bone's **head** is put on the recorded world position of its joint, scaled to the rig and anchored on the recorded body. This is the part of MonkeMocap's data model that fixes placement: absolute world positions, not an offset from a rest pose.
* Bone **orientation** is the recorded rotation **change** since the first sample applied to the rig's own rest orientation, then swung so the bone's axis points at the next recorded joint (torso → head, upper arm → forearm → hand → index, finger segment → next segment). A tracker's absolute rotation describes the tracker's axes, not the bone's, so applying it directly would tip an upright torso sideways. The delta keeps the rig's bind pose; the aim keeps every limb connected. Fingers are the exception: their direction comes from the recorded joint positions and their roll keeps the rig's rest roll relative to the hand, because a finger has no meaningful tracked orientation and a tracker delta would spin it about its own axis.
* The recording is anchored on the joint that maps to the rig's body (MonkeMocap anchors on the body position too), so the game's rig root sitting at head height does not put the whole avatar on the floor. The anchor and the scale are printed on import.
* The clip's **frame-0 facing** is measured from the recorded body rotation and rotated about the anchor onto the rig's rest facing (the body bone's local `+Z`). Positions and rotation deltas are rotated together, so the joints and the bone orientations agree. Without this, a recording made while facing any direction other than the rig's own could keep the rig's rest heading in its bones while placing the joints the other way round — which is exactly what makes the head and torso look backwards.
* Each matched bone also gets a `location` channel, because its recorded position is not on its rig parent's end. Unmatched target bones follow their parents, so a rig with extra joints (more fingers, toes, props) is fine. A connected bone is disconnected by `Recorded positions` so its location can be applied (Blender ignores the location of a connected bone); `Rotation deltas` leaves the rig's connections untouched.
* **Rotation deltas** mode keeps the previous behaviour: the rig's own rest pose is preserved and only the rotation change from the first frame is applied. That mode also uses chain gluing (hands on the ends of forearms, ...) and root translation on the topmost ancestor of the recorded root.
* A target bone is never driven by two source joints.

The mapping is printed to the Blender console after every import, for example:

```
[Gorilla Animate] example_recording.gamc -> GorillaRig
[Gorilla Animate] mapped 10/10 joints
    root             -> root
    body             -> body
    head             -> head
    hand.L           -> hand.L
    ...
```

Joints whose stored rotation jumps between samples are reported as well:

```
[Gorilla Animate] fast rotation: hand.L           -> hand.L           max  61 deg/sample, avg   9.2, net    83, worst at sample 438
```

`max` is the largest single-sample step, `avg` the average step and `net` the total turn from first to last sample. A high `avg` with a small `net` means the joint was shaken or the tracking jittered; a high `net` means it really turned that far. Stored quaternions may flip sign between samples (a rotation and its negation are the same rotation), which is not counted as a jump. If a joint is noisy, raise **Smoothing**; `0` keeps the raw recording.

Constraints on the target rig are listed before they are muted:

```
[Gorilla Animate] rig check: 2 constraints on Gorilla_IK_Rig
    hand.L           IK -> Gorilla_IK_Rig/IK_hand.L
    forearm.R        COPY_ROTATION
```

The sidebar panel also shows the constraint count for the selected rig, so you can see it before importing.

Bones that had to be repositioned onto their chain parent are listed too, and so is a gap that already exists in the rig's rest pose:

```
[Gorilla Animate] connected 1 bone(s) to the end of their chain:
    hand.L           -> forearm.L        (was parented elsewhere in the rig)
[Gorilla Animate] rig gap: the rest pose leaves 0.080 between hand.R and the end of forearm.R
```

`connected` means the import fixed the hand/arm connection. `rig gap` is different: the rig itself leaves that space in its rest pose, so no import can close it — fix the rig (or the IK control placement) if it looks wrong.

After baking, the importer re-evaluates the rig on a few frames and measures the same chains again, because constraints you left active can still move a bone away from the values that were keyed:

```
[Gorilla Animate] still detached: hand.L is 2.011 from the end of forearm.L after evaluation
[Gorilla Animate] a constraint, driver or Stretch To modifier is still moving those bones; mute it or apply the visual transform
```

If that line appears with **Mute constraints** on, the remaining movement is a driver, a *Stretch To* / *Copy Transforms* on a bone that needs manual muting, or the mesh is skinned to a bone the importer does not drive. The sidebar shows the same count after the import.

Finally, the importer checks which animated bones actually deform the mesh. A rig can animate control bones while the visible mesh is weighted to a separate set of deform bones; the bones then move and the mesh does not:

```
[Gorilla Animate] 8 animated bone(s) have no weighted vertices: body, hand.L, forearm.L, ...
[Gorilla Animate] the mesh is probably skinned to other (deform) bones; those bones move, the mesh will not
```

The sidebar shows **N animated bones move no vertices** in that case. The fix is to retarget onto the bones the mesh is actually weighted to (or re-weight the mesh), not a setting in the add-on.

### Legacy recordings (plugin 1.0.0)

Recordings made with **Gorilla Animate 1.0.0** have `flags = 0`. That build only sampled the head, hands and fingers, so there is no torso, arm or leg data in the file to retarget. On import the console says so and the sidebar shows **Legacy recording: no torso/arms/legs**:

```
[Gorilla Animate] legacy recording: made by Gorilla Animate 1.0.0, so it only holds the head, hands and fingers. The torso, arms and legs cannot be animated from it. Re-record with plugin 1.1.0 or newer for the whole body.
```

No Blender setting can add joints that were never captured; re-record with plugin 1.1.0 or newer. Every import also reports the real capture rate and any recorded joint that has no matching bone on the rig:

```
[Gorilla Animate] 592 samples over 16.40 s = 36.0 Hz (header says 60 fps, scene plays at 60 fps)
[Gorilla Animate] no bone on this rig for: spine, chest, neck
```

### Using the result

* Scrub the timeline to review the take, then render or export as usual.
* Parent/copy the action onto another rig, or use the baked armature as a retarget source.

---

## What is and is not recorded

* **Local player only.** Other players are not recorded.
* Transform data only: no mesh, cosmetics, face tracking, or voice.
* Fingers use the game's `VRMap` finger bones when available.
* Scale is stored per joint. The Blender add-on uses it for height matching and otherwise leaves the rig's own proportions alone.
* The bone list comes from the rendered gorilla skeleton, so a game update that changes the model changes the recording automatically. Joints the add-on cannot identify are stored but ignored on import.
* The start of every recording is logged to the BepInEx console (`Gorilla Animate: N joints recorded ...`) so the joint list can be checked against a rig.

---

## Safety / fairness

This is a recording tool. It does not change movement, physics, tags, or anything sent to other players.

Modding is tolerated by Another Axiom, but public-lobby rules still apply. If you want to be extra safe, record in a private room. Do not use other mods to interfere with public lobbies.

---

## Build from source

```powershell
cd src\GorillaAnimate
dotnet build -c Release
```

`GamePath` in `GorillaAnimate.csproj` defaults to:

```
D:\SteamLibrary\steamapps\common\Gorilla Tag
```

Change it if your install is elsewhere. The post-build step copies the DLL to this folder and to `package/BepInEx/plugins/GorillaAnimate/`.

Target framework: `netstandard2.1`, references the game's own `Assembly-CSharp.dll`, `UnityEngine.*`, `Unity.InputSystem`, Photon, and BepInEx 5.

---

## Uninstall

Delete:

```
<Gorilla Tag>\BepInEx\plugins\GorillaAnimate\
```

Optionally delete `BepInEx\config\com.rayan.gorillaanimate.cfg`.

Recordings are inside the deleted plugin folder, so copy them somewhere first if you want to keep them.
